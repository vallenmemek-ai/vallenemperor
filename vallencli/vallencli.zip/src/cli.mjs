#!/usr/bin/env node
import { createInterface } from 'node:readline'
import { spawn, spawnSync } from 'node:child_process'
import { appendFileSync, existsSync, mkdirSync, readFileSync } from 'node:fs'
import { homedir, platform } from 'node:os'
import { PassThrough } from 'node:stream'
import { StringDecoder } from 'node:string_decoder'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { ANSI, color, stripAnsi, stringWidth, clipWidth, HELP, collectHealthChecks, startupBox, chatBoxRedrawSequence, formatChatBox, formatStatus, formatThinkingActivity, formatSuggestions, colorizeDiff, THINKING_FACES, THINKING_VERBS, formatStatusBar, formatApprovalBox, formatToolResult, formatFileEditResult, formatSessionSummary, formatTip, formatUserMessage, formatToolCall, formatToolLine, buildEditPreview, toAscii, fmtTokens, fmtDuration, refreshThemeColors, invalidateGit } from './cli-ui.mjs'
import { loadSavedTheme, shimmerText, getColorLevel } from './cli-theme.mjs'
import { createCardStream, formatResponseCard } from './cli-markdown.mjs'
import { fileToken, suggestFiles } from './cli-files.mjs'
import { suggestCommands, commandToken, findCommand, needsMoreInput } from './cli-suggest.mjs'
import { createLocalCommandHandler } from './cli-commands.mjs'
export { HELP, collectHealthChecks, chatBoxRedrawSequence, formatChatBox, formatStatus, formatThinkingActivity } from './cli-ui.mjs'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..')
const CORE_PATH = join(ROOT, 'vallenagent', 'dist', 'index.js')
function write(output, text = '') {
  const line = `${text}${text.endsWith('\n') ? '' : '\n'}`
  output.write(process.env.VALLEN_ASCII === '1' ? toAscii(line) : line)
}

function toolError(result) {
  try { return JSON.parse(result)?.error || null } catch { return null }
}

function hasToolError(result) { return Boolean(toolError(result)) }

// Tool events carry no stable id across versions: try the likely ones, fall back to the tool name.
const toolKey = tool => tool?.id ?? tool?.callId ?? tool?.toolCallId ?? tool?.name
// Short "key  value" lines describing a non-terminal tool call for the approval box.
const summarizeArgs = args => Object.entries(args && typeof args === 'object' ? args : {}).slice(0, 4).map(([key, value]) => [key, String(typeof value === 'string' ? value : JSON.stringify(value)).replace(/\s+/g, ' ').slice(0, 120)])
// Event names an agent may use for streamed answer text.
// Edit-style tools: the approval box shows a +/- preview instead of raw argument dumps.
const editPreviewFor = request => (/patch|write|edit|replace/i.test(String(request?.name)) ? buildEditPreview(request.args) : null)
const stripEditArgs = args => Object.fromEntries(Object.entries(args && typeof args === 'object' ? args : {}).filter(([key]) => !/^(old|new|content|text|diff|patch)/i.test(key)))
const DELTA_EVENTS = new Set(['text_delta', 'delta', 'response_delta', 'message_delta', 'content_delta', 'assistant_delta'])

function safeInput(value) { return String(value).replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g, '') }

export async function runCli(options = {}) {
  const input = options.input || process.stdin
  const output = options.output || process.stdout
  const core = options.core || await import(pathToFileURL(CORE_PATH).href)
  const state = { busy: false, closing: false, pendingApproval: null, activeTurn: null, mcpServers: [], rl: null, generation: 0, queue: [], waiter: null, ended: false, started: false, terminalBuffer: '', robotVisible: false, robotActivity: 'THINKING', turnStartedAt: 0, thinkingFaceIndex: 0, thinkingVerbIndex: 0, thinkingTimer: null, thinkingTicks: 0, spinnerFrame: 0, statusRows: 0, sugRows: 0, sugReserved: 0, sugTimer: null, sug: { token: null, kind: 'cmd', fileStart: 0, items: [], index: 0, top: 0, open: false, dismissed: null }, pastes: new Map(), pasteSeq: 0, lastSigint: 0, sessionStartedAt: Date.now(), turns: 0, toolCalls: 0, toolErrors: 0, toolStarts: new Map(), terminalOutputs: new Map(), terminalOutputTruncated: new Set(), lastTerminalOutput: '', stream: null, streamedChars: 0, sessionAllow: new Set(), lastTokens: 0, turnToolCalls: 0, toolCallText: new Map() }
  let agent = options.agent
  if (!agent) agent = options.createAgent ? options.createAgent({ onMcpStatus: servers => { state.mcpServers = servers; if (state.started) refreshStatus() } }) : new core.AIAgent({ onMcpStatus: servers => { state.mcpServers = servers; if (state.started) refreshStatus() } })
  state.mcpServers = agent.mcpManager?.getStatus?.() || []
  const healthCheck = options.healthCheck || ((target, servers) => collectHealthChecks(target, servers, core))
  const bannerText = options.bannerText ?? (() => { try { return readFileSync(join(ROOT, 'banner.txt'), 'utf8') } catch { return '' } })()
  const sharedCommand = options.handleSharedCommand || core.handleCommand
  const noColorMode = process.env.NO_COLOR || output.isTTY === false
  const fixAscii = value => (process.env.VALLEN_ASCII === '1' ? toAscii(value) : value)
  const out = value => output.write(fixAscii(noColorMode ? stripAnsi(value) : value))
  const verboseTools = process.env.VALLEN_VERBOSE === '1'
  const interactive = Boolean(input.isTTY && output.isTTY)
  const compactUi = interactive && ((output.columns || 80) < 70 || (output.rows || 40) < 24)
  const termWidth = () => Math.max(40, output.columns || 80)
  const boxWidth = () => Math.max(36, Math.min((output.columns || 80) - 2, 80))
  const home = process.env.VALLENEMPEROR_HOME || join(homedir(), '.vallenemperor')
  const historyFile = join(home, 'cli_history')
  if (interactive) { loadSavedTheme(home); refreshThemeColors() }
  const setTitle = text => { if (interactive) output.write(`\x1b]0;${text}\x07`) }
  let readerInput = input
  const loadHistory = () => {
    if (!interactive) return []
    try { return readFileSync(historyFile, 'utf8').split('\n').filter(Boolean).slice(-500).reverse() } catch { return [] }
  }
  const saveHistory = line => {
    if (!interactive || !line.trim() || /^\/token\b/i.test(line) || /\[Pasted text #\d+/.test(line)) return
    try { mkdirSync(home, { recursive: true }); appendFileSync(historyFile, `${line}\n`, { mode: 0o600 }) } catch {}
  }
  const pasteMode = on => { if (interactive) output.write(on ? '\x1b[?2004h' : '\x1b[?2004l') }
  const resetPasteMode = () => { try { output.write('\x1b[?2004l') } catch {} }
  function lockInputEcho() {
    const rl = state.rl
    if (!input.isTTY || !output.isTTY || !rl || typeof rl._writeToOutput !== 'function' || state.restoreInputEcho) return
    const originalOutput = rl.output
    rl.output = { write() {} }
    state.restoreInputEcho = () => {
      if (state.rl === rl) {
        if (!rl.closed) rl.write(null, { ctrl: true, name: 'u' })
        rl.output = originalOutput
      }
      state.restoreInputEcho = null
    }
  }
  function unlockInputEcho() { state.restoreInputEcho?.() }
  const robotLine = activity => {
    const thinking = activity === 'THINKING'
    const label = thinking
      ? `${formatThinkingActivity(Date.now() - state.turnStartedAt, state.thinkingFaceIndex, state.thinkingVerbIndex, interactive ? state.spinnerFrame : null)}${interactive && state.lastTokens > 0 ? ` · ${fmtTokens(state.lastTokens)} ctx` : ''}${interactive ? ' · Ctrl+C to stop' : ''}`
      : `[o_o] ${activity}`
    if (interactive && getColorLevel() > 0) {
      if (thinking) return `  ${shimmerText(label, state.thinkingTicks)}`
      return color(`  ${activity === 'APPROVAL' ? '⚠' : '⚙'} ${clipWidth(activity, Math.max(12, termWidth() - 6))}`, activity === 'APPROVAL' ? ANSI.red : ANSI.yellow)
    }
    return color(`  ${label}`, ANSI.dim)
  }
  function stopThinkingTicker() {
    if (state.thinkingTimer) clearInterval(state.thinkingTimer)
    state.thinkingTimer = null
  }
  function startThinkingTicker() {
    if (!output.isTTY || !input.isTTY || state.thinkingTimer) return
    state.thinkingTicks = 0
    state.thinkingTimer = setInterval(() => {
      if (!state.busy || state.robotActivity !== 'THINKING') return stopThinkingTicker()
      state.thinkingTicks++
      state.spinnerFrame = state.thinkingTicks
      if (state.thinkingTicks % 25 === 0) {
        state.thinkingFaceIndex = Math.floor(Math.random() * THINKING_FACES.length)
        state.thinkingVerbIndex = Math.floor(Math.random() * THINKING_VERBS.length)
      }
      output.write('\r\x1b[2K')
      out(robotLine('THINKING'))
      state.robotVisible = true
    }, 120)
    state.thinkingTimer.unref?.()
  }
  function showRobot(activity) {
    state.robotActivity = activity
    if (activity === 'THINKING') startThinkingTicker()
    else stopThinkingTicker()
    if (output.isTTY && input.isTTY) {
      if (state.robotVisible) output.write('\r\x1b[2K')
      out(robotLine(activity))
      state.robotVisible = true
    } else write(output, noColorMode ? stripAnsi(robotLine(activity)) : robotLine(activity))
  }
  function displayLine(value) {
    const text = noColorMode ? stripAnsi(value) : value
    if (state.busy) {
      if (output.isTTY && input.isTTY) {
        if (!state.robotVisible) showRobot(state.pendingApproval ? 'APPROVAL' : state.robotActivity)
        output.write('\r\x1b[2K')
        write(output, text)
        out(robotLine(state.robotActivity))
      } else {
        write(output, text)
        showRobot(state.pendingApproval ? 'APPROVAL' : state.robotActivity)
      }
      return
    }
    if (state.rl && interactive && !state.closing) {
      clearPromptArea()
      write(output, text)
      drawPrompt()
    } else write(output, text)
  }

  function captureTerminalOutput(event) {
    const id = String(event?.id || 'unknown')
    const current = state.terminalOutputs.get(id) || ''
    const chunk = safeInput(event?.chunk || '')
    if (current.length + chunk.length > 200_000) state.terminalOutputTruncated.add(id)
    state.terminalOutputs.set(id, current + chunk.slice(0, Math.max(0, 200_000 - current.length)))
  }
  function flushTerminalChunk(id, tool, durationMs = 0) {
    const raw = state.terminalOutputs.get(String(id)) || ''
    state.terminalOutputs.delete(String(id))
    const truncated = state.terminalOutputTruncated.delete(String(id))
    const text = raw.replace(/\n?__VALLEN_CWD__=.*?(?:\n|$)/g, '\n').trim()
    if (!text) return false
    state.lastTerminalOutput = `${text}${truncated ? '\n[CLI preview limit reached; remaining output omitted]' : ''}`
    const lines = state.lastTerminalOutput.split('\n')
    let exit = 'unknown'
    try { exit = JSON.parse(tool.result)?.exit_code ?? exit } catch {}
    const command = String(tool.args?.command || '').replace(/\s+/g, ' ').trim()
    const preview = lines.length <= 8 ? lines : [...lines.slice(0, 4), `… ${lines.length - 8} lines hidden · use /output`, ...lines.slice(-4)]
    const title = ` Terminal · $ ${command} · exit ${exit} · ${fmtDuration(durationMs)} `
    const card = formatResponseCard(`${lines.length} lines${lines.length > 8 ? ' · /output expands' : ''}\n\n${preview.join('\n')}`, title, boxWidth(), { markdown: false })
    displayLine(card)
    return true
  }

  function renderChatBox(message) {
    state.mcpServers = agent.mcpManager?.getStatus?.() || state.mcpServers
    const width = Math.max(36, output.columns || 80)
    const status = formatStatus(agent, state.mcpServers, 'VALLENEMPEROR', width - 4)
    const box = formatChatBox(status, `› ${message}`, width)
    write(output, noColorMode ? stripAnsi(box) : box)
  }

  function refreshStatus(activity = state.pendingApproval ? 'APPROVAL' : state.busy ? 'WORKING' : 'VALLENEMPEROR') {
    state.mcpServers = agent.mcpManager?.getStatus?.() || state.mcpServers
    if (state.busy) {
      showRobot(activity)
      return
    }
    if (state.robotVisible) {
      output.write('\r\x1b[2K')
      state.robotVisible = false
    }
    if (!interactive) { displayLine(formatStatus(agent, state.mcpServers, activity, output.columns || 80)); return }
    clearPromptArea()
    drawPrompt()
  }
  // One live status line + the input prompt. Erased on Enter, so it never piles up in the chat history.
  function drawPrompt() {
    if (state.closing || !state.rl || !interactive) return
    const rule = color('─'.repeat(Math.max(10, termWidth() - 1)), ANSI.dim)
    out(`${rule}\n${formatStatusBar(agent, state.mcpServers, { activity: state.pendingApproval ? 'APPROVAL' : 'VALLENEMPEROR', width: termWidth() - 1, startedAt: state.sessionStartedAt, hint: 'Ctrl+C stop · /help' })}\n`)
    state.rl.setPrompt(fixAscii(`${noColorMode ? '›' : color('›', ANSI.bold + ANSI.cyan)} `))
    state.rl.prompt(true)
    state.statusRows = 2
    state.sugRows = 0
    state.sugReserved = 0
    state.sug.token = null
    scheduleSuggest()
  }
  function prompt() { drawPrompt() }
  // Wipe status line, input line and any suggestion list (cursor is on the input line).
  function clearPromptArea() {
    if (!state.statusRows) return
    output.write(`\r\x1b[${state.statusRows}A\x1b[J`)
    state.statusRows = 0
    state.sugRows = 0
    state.sugReserved = 0
  }

  // ---- command suggestions (dropdown under the input line) ----
  function updateSuggestions() {
    const sug = state.sug
    const line = state.rl?.line ?? ''
    const ok = interactive && state.rl && !state.busy && !state.closing && stringWidth(line) < termWidth() - 6
    const cmd = ok ? commandToken(line) : null
    const file = ok && !cmd ? fileToken(line) : null
    const token = cmd || (file ? `@${file.partial}` : null)
    if (token !== sug.token) {
      sug.token = token
      sug.kind = file ? 'file' : 'cmd'
      sug.fileStart = file ? file.start : 0
      sug.items = cmd ? suggestCommands(cmd) : file ? suggestFiles(file.partial, agent.config?.terminal?.cwd || process.cwd()) : []
      sug.index = 0
      sug.top = 0
      sug.dismissed = null
    }
    sug.open = Boolean(token) && sug.dismissed !== token && (sug.kind === 'cmd' || sug.items.length > 0)
    return sug
  }
  function scheduleSuggest() {
    if (!interactive || state.sugTimer) return
    state.sugTimer = setImmediate(() => { state.sugTimer = null; paintSuggestions() })
  }
  function paintSuggestions() {
    if (!interactive || !state.rl || state.busy || state.closing) return
    const sug = updateSuggestions()
    const lines = sug.open ? formatSuggestions(sug.items, sug.index, termWidth(), sug.top, 6, sug.kind === 'cmd' ? String(sug.token || '').slice(1) : '') : []
    if (!lines.length && !state.sugRows) return
    const pos = typeof state.rl.getCursorPos === 'function' ? state.rl.getCursorPos() : { cols: 2 + (state.rl.cursor || 0) }
    let seq = ''
    if (state.sugReserved > 0) seq += '\x1b[1B\r\x1b[J\x1b[1A'
    for (const line of lines) seq += `\r\n\x1b[2K${line}`
    if (lines.length) seq += `\x1b[${lines.length}A`
    seq += `\x1b[${pos.cols + 1}G`
    out(seq)
    state.sugRows = lines.length
    state.sugReserved = Math.max(state.sugReserved, lines.length)
  }
  function fillLine(text) {
    const rl = state.rl
    rl.write(null, { ctrl: true, name: 'e' })
    rl.write(null, { ctrl: true, name: 'u' })
    rl.write(text)
    scheduleSuggest()
  }
  // Keys that drive the dropdown. Returns true when the key was consumed (readline never sees it).
  function handleSuggestKey(key) {
    if (!interactive || !state.rl || state.busy || state.closing) return false
    const up = key === '\x1b[A' || key === '\x1bOA'
    const down = key === '\x1b[B' || key === '\x1bOB'
    const tab = key === '\t'
    const esc = key === '\x1b'
    const enter = key === '\r' || key === '\n'
    if (!(up || down || tab || esc || enter)) return false
    const sug = updateSuggestions()
    if (!sug.open || !sug.items.length) return false
    if (up || down) {
      const count = sug.items.length
      sug.index = (sug.index + (down ? 1 : -1) + count) % count
      if (sug.index < sug.top) sug.top = sug.index
      if (sug.index >= sug.top + 6) sug.top = sug.index - 5
      paintSuggestions()
      return true
    }
    if (esc) { sug.dismissed = sug.token; paintSuggestions(); return true }
    const item = sug.items[sug.index]
    if (sug.kind === 'file') {
      // Enter on an already-complete mention just sends the message; otherwise insert the highlighted entry.
      if (enter && item.fillText.trimEnd() === sug.token) return false
      const line = state.rl.line ?? ''
      fillLine(`${line.slice(0, sug.fileStart)}${item.fillText}`)
      return true
    }
    if (tab) { fillLine(`${item.name}${item.args ? ' ' : ''}`); return true }
    if (findCommand(sug.token)) return false // exact command typed: Enter just runs it
    if (needsMoreInput(item) || item.fuzzy) { fillLine(`${item.name}${item.args ? ' ' : ''}`); return true }
    fillLine(item.name)
    readerInput.write('\r')
    return true
  }

  // ---- raw input: suggestion keys + bracketed paste folding ----
  const decoder = new StringDecoder('utf8')
  let pasteBuffer = null
  function foldPaste(text) {
    const normalized = text.replace(/\r\n?/g, '\n').replace(/\n+$/, '')
    if (!normalized.includes('\n')) return normalized
    const id = ++state.pasteSeq
    state.pastes.set(id, normalized)
    return `[Pasted text #${id} +${normalized.split('\n').length} lines]`
  }
  function filterPaste(text) {
    let rest = text
    let result = ''
    while (rest.length) {
      if (pasteBuffer === null) {
        const start = rest.indexOf('\x1b[200~')
        if (start === -1) { result += rest; break }
        result += rest.slice(0, start)
        rest = rest.slice(start + 6)
        pasteBuffer = ''
      } else {
        const end = rest.indexOf('\x1b[201~')
        if (end === -1) { pasteBuffer += rest; break }
        pasteBuffer += rest.slice(0, end)
        rest = rest.slice(end + 6)
        result += foldPaste(pasteBuffer)
        pasteBuffer = null
      }
    }
    return result
  }
  function onInputData(chunk) {
    const text = typeof chunk === 'string' ? chunk : decoder.write(chunk)
    // While an approval is pending a single y / n / a keypress answers it immediately (no Enter needed).
    if (state.pendingApproval && pasteBuffer === null && /^[yna]$/i.test(text)) { enqueue({ line: text.toLowerCase(), generation: state.generation }); return }
    if (pasteBuffer === null) {
      // Several arrow presses can arrive glued together in one chunk (key repeat): handle each one.
      const keys = /^(?:\x1b[\[O][AB])+$/.test(text) ? text.match(/\x1b[\[O][AB]/g) : [text]
      if (keys.every(handleSuggestKey)) return
    }
    const forwarded = filterPaste(text)
    if (forwarded) readerInput.write(forwarded)
  }
  function suspendInput() { if (interactive) { pasteMode(false); input.pause() } }
  function resumeInput() { if (interactive) { input.resume(); readerInput.resume?.(); pasteMode(true) } }
  function detachReader() {
    state.generation++
    state.rl?.close()
    state.rl = null
    state.statusRows = 0
    suspendInput()
  }
  function enqueue(item) {
    if (state.waiter) { const resolveLine = state.waiter; state.waiter = null; resolveLine(item) }
    else state.queue.push(item)
  }
  function attachReader() {
    const generation = ++state.generation
    const rl = createInterface({ input: readerInput, output, terminal: interactive, history: loadHistory(), historySize: 500 })
    state.rl = rl
    const onKey = () => scheduleSuggest()
    if (interactive) readerInput.on('keypress', onKey)
    rl.on('line', raw => {
      state.sugRows = 0
      const line = raw.replace(/\[Pasted text #(\d+) \+\d+ lines\]/g, (match, id) => state.pastes.get(Number(id)) ?? match)
      saveHistory(raw)
      enqueue({ line, raw, generation })
    })
    rl.on('close', () => {
      readerInput.off('keypress', onKey)
      unlockInputEcho()
      if (state.generation === generation) enqueue({ eof: true, generation })
    })
    rl.on('SIGINT', () => {
      if (state.busy) { enqueue({ line: '/stop', generation }); return }
      if (rl.line) { rl.write(null, { ctrl: true, name: 'u' }); scheduleSuggest(); return }
      const now = Date.now()
      if (now - state.lastSigint < 2000) { enqueue({ line: '/exit', synthetic: true, generation }); return }
      state.lastSigint = now
      displayLine(color('Press Ctrl+C again to exit.', ANSI.dim))
    })
    resumeInput()
    prompt()
  }
  function readHiddenToken() {
    if (!input.isTTY || !output.isTTY) return { error: 'Hidden token entry requires an interactive terminal.' }
    if (platform() === 'win32') return { error: 'Secure token input is not yet supported on Windows.' }
    detachReader()
    const script = "trap 'stty echo' EXIT HUP INT TERM; stty -echo || exit 1; printf '9router API token: ' >&2; IFS= read -r token || exit 1; printf '\\n' >&2; printf '%s' \"$token\""
    const result = spawnSync('/bin/sh', ['-c', script], { stdio: ['inherit', 'pipe', 'inherit'], encoding: 'utf8', maxBuffer: 1024 * 1024 })
    attachReader()
    if (result.error || result.status !== 0) return { error: `Hidden token input failed${result.error ? `: ${result.error.message}` : ''}.` }
    return { value: result.stdout }
  }
  function nextLine() {
    if (state.queue.length) return Promise.resolve(state.queue.shift())
    if (state.ended) return Promise.resolve({ eof: true })
    return new Promise(resolveLine => { state.waiter = resolveLine })
  }
  function settleApproval(allowed) {
    const pending = state.pendingApproval
    if (!pending) return
    state.pendingApproval = null
    clearTimeout(pending.timer)
    pending.resolve(allowed)
    refreshStatus()
  }
  function askApproval(request) {
    const mode = core.approvalMode(agent.config?.agentApproval)
    const server = core.mcpServerFromTool(request.name)
    const trusted = server ? agent.config?.mcpServers?.[server]?.trusted === true : false
    if (!core.requiresApproval({ name: request.name, args: request.args }, mode, trusted)) return Promise.resolve(true)
    if (server && core.isMcpApproved(agent.getSessionId(), server)) return Promise.resolve(true)
    if (interactive && request.name !== 'terminal' && state.sessionAllow.has(request.name)) return Promise.resolve(true)
    if (state.pendingApproval) return Promise.resolve(false)
    return new Promise(resolveApproval => {
      const timer = setTimeout(() => {
        write(output, 'Approval timeout; tool denied.')
        settleApproval(false)
      }, options.approvalTimeoutMs || 5 * 60_000)
      const canAlways = interactive && request.name !== 'terminal'
      state.pendingApproval = { resolve: resolveApproval, timer, server, name: request.name, canAlways }
      const command = request.name === 'terminal' ? `\nCommand: ${String(request.args.command || '').slice(0, 1200)}` : ''
      showRobot('APPROVAL')
      if (interactive) {
        setTitle('VallenEmperor · approval needed')
        output.write('\x07')
        displayLine(formatApprovalBox({ name: request.name, command: request.name === 'terminal' ? String(request.args.command || '').slice(0, 1200) : '', server: server || '', details: request.name === 'terminal' ? [] : summarizeArgs(editPreviewFor(request) ? stripEditArgs(request.args) : request.args), preview: editPreviewFor(request), canAlways }, boxWidth()))
      } else displayLine(`Allow tool ${request.name}? [y/N]${command}`)
    })
  }
  function printResponse(text, { markdown = false, footer = '' } = {}) {
    const width = boxWidth()
    if (interactive) displayLine(formatResponseCard(String(text || ''), ' ☤ VallenEmperor CLI ', width, { markdown, footer }))
    else displayLine(core.formatResponseBox(String(text || ''), ' ☤ VallenEmperor CLI ', width))
  }
  // Streamed answer text is rendered line by line into one framed card; any tool output closes the card first.
  function pushStream(piece) {
    if (!state.stream) state.stream = createCardStream({ title: ' ☤ VallenEmperor CLI ', width: boxWidth(), write: displayLine })
    state.stream.push(piece)
  }
  function closeStream(footer = '') {
    if (!state.stream) return
    const stream = state.stream
    state.stream = null
    stream.end(footer)
  }
  // "4.2s · 3 tools · 18k ctx" shown in the bottom edge of the final answer card.
  function turnFooter() {
    if (!state.turnStartedAt) return ''
    return [fmtDuration(Date.now() - state.turnStartedAt), state.turnToolCalls ? `${state.turnToolCalls} tool${state.turnToolCalls === 1 ? '' : 's'}` : '', state.lastTokens > 0 ? `${fmtTokens(state.lastTokens)} ctx` : ''].filter(Boolean).join(' · ')
  }
  function noteTokens() {
    try { state.lastTokens = Number(agent.getContextStats?.()?.promptTokens) || state.lastTokens } catch {}
  }

  out(`${startupBox(agent, bannerText, await healthCheck(agent, state.mcpServers), output.columns || 80, { fancy: interactive, compact: compactUi })}\n`)
  if (interactive) { if (!compactUi) out(`${formatTip()}\n`); output.write('\x1b[22;0t'); setTitle('VallenEmperor') }
  state.started = true
  if (interactive) {
    // readline reads from a proxy so the dropdown keys (Tab/arrows/Esc/Enter) and bracketed paste can be handled first.
    const proxy = new PassThrough()
    proxy.isTTY = true
    proxy.setRawMode = mode => { if (typeof input.setRawMode === 'function') input.setRawMode(mode); return proxy }
    readerInput = proxy
    input.on('data', onInputData)
    process.once('exit', resetPasteMode)
  }
  refreshStatus()
  attachReader()

  async function runTurn(message, displayMessage = message) {
    state.turnStartedAt = Date.now()
    state.thinkingFaceIndex = Math.floor(Math.random() * THINKING_FACES.length)
    state.thinkingVerbIndex = Math.floor(Math.random() * THINKING_VERBS.length)
    state.busy = true
    state.turns++
    state.streamedChars = 0
    state.turnToolCalls = 0
    setTitle('VallenEmperor · working…')
    lockInputEcho()
    if (!interactive) renderChatBox(displayMessage)
    refreshStatus('THINKING')
    state.activeTurn = (async () => {
      try {
        const result = await agent.runTurn({ message, surfaceId: 'vallenemperor' }, {
          requestApproval: request => askApproval(request),
          onEvent: event => {
            if (interactive && DELTA_EVENTS.has(event.type)) {
              const piece = event.text ?? event.delta ?? event.content ?? event.chunk
              if (typeof piece === 'string' && piece) { state.streamedChars += piece.length; pushStream(piece) }
              return
            }
            if (event.type === 'thinking') refreshStatus('THINKING')
            else if (event.type === 'tool_start') {
              closeStream()
              const args = event.tool.args || {}
              const target = String(args.path || args.file_path || args.command || args.query || args.pattern || args.name || '')
              showRobot(`WORKING · ${event.tool.name}${target ? ` · ${target}` : ''}`)
              const text = event.tool.preview || core.formatToolStart(event.tool.name, event.tool.args)
              state.toolCalls++
              state.turnToolCalls++
              state.toolStarts.set(toolKey(event.tool), Date.now())
              state.toolCallText.set(toolKey(event.tool), text)
              if (!interactive) displayLine(text)
              else if (verboseTools) displayLine(formatToolCall(text, { width: boxWidth() }))
            } else if (event.type === 'tool_end') {
              closeStream()
              const startedAt = state.toolStarts.get(toolKey(event.tool))
              const terminalOutputShown = event.tool.name === 'terminal' && flushTerminalChunk(toolKey(event.tool), event.tool, startedAt ? Date.now() - startedAt : 0)
              const callText = state.toolCallText.get(toolKey(event.tool)) || String(event.tool.name || 'tool')
              state.toolCallText.delete(toolKey(event.tool))
              state.toolStarts.delete(toolKey(event.tool))
              const failed = hasToolError(event.tool.result)
              if (failed) state.toolErrors++
              if (event.tool.name === 'shell' && String(toolError(event.tool.result)).includes('Tool not found')) displayLine('Unsupported tool "shell". Use "terminal" instead.')
              else if (!terminalOutputShown && (event.tool.name !== 'skill_view' || failed)) {
                const text = event.tool.preview || core.formatToolEnd(event.tool.name, event.tool.args, event.tool.result)
                const durationMs = startedAt ? Date.now() - startedAt : 0
                const editTool = ['patch', 'write_file'].includes(event.tool.name)
                const quiet = interactive && !verboseTools && !failed && !/^\s*@@ /m.test(stripAnsi(String(text || '')))
                displayLine(editTool
                  ? formatFileEditResult(event.tool.name, event.tool.args, event.tool.result, { durationMs, width: boxWidth() })
                  : quiet ? formatToolLine(callText, text, { durationMs, width: boxWidth() })
                  : interactive ? `${verboseTools ? '' : `${formatToolCall(callText, { width: boxWidth() })}\n`}${formatToolResult(text, { error: failed, durationMs, width: boxWidth() })}`
                  : colorizeDiff(text))
              }
              showRobot('THINKING')
            } else if (event.type === 'terminal_output') captureTerminalOutput(event.output)
            else if (event.type === 'review_complete') displayLine(event.summary)
            else if (event.type === 'review_error') displayLine(color(`Review error: ${event.error}`, ANSI.yellow))
            else if (event.type === 'telemetry') { noteTokens(); refreshStatus('WORKING') }
          }
        })
        const streamed = state.streamedChars > 0
        const footer = turnFooter()
        closeStream(footer)
        if (result.completionStatus === 'incomplete') displayLine(color('Turn incomplete; check remaining work and errors above.', ANSI.yellow))
        if (!streamed) printResponse(result.response, { markdown: true, footer })
      } catch (error) {
        closeStream()
        displayLine(color(`Agent error: ${error instanceof Error ? error.message : String(error)}`, ANSI.red))
      } finally {
        stopThinkingTicker()
        if (interactive && state.turnStartedAt && Date.now() - state.turnStartedAt > 20_000) { output.write('\x07'); if (process.env.VALLEN_OSC9 === '1') output.write('\x1b]9;VallenEmperor: turn finished\x07') }
        state.streamedChars = 0
        state.toolStarts.clear()
        invalidateGit()
        setTitle('VallenEmperor')
        state.turnStartedAt = 0
        state.busy = false
        state.activeTurn = null
        unlockInputEcho()
        refreshStatus()
      }
    })()
  }

  async function enterShell() {
    if (platform() === 'win32') { write(output, 'Direct shell unavailable: CLI currently supports POSIX hosts only.'); return }
    detachReader()
    const shell = process.env.SHELL || '/bin/sh'
    write(output, `Entering ${shell}; type exit to return to VallenCLI.`)
    await new Promise(resolveShell => {
      const child = spawn(shell, ['-i'], { cwd: agent.config?.terminal?.cwd || process.cwd(), stdio: 'inherit' })
      child.once('error', error => { write(output, `Shell error: ${error.message}`); resolveShell() })
      child.once('exit', (code, signal) => { write(output, `Shell closed (${signal || (code ?? 0)}).`); resolveShell() })
    })
    attachReader()
    refreshStatus()
  }

  const localCommand = createLocalCommandHandler({ agent, core, state, output, printResponse, readHiddenToken, settleApproval, enqueue, out, refreshStatus, healthCheck, enterShell, runTurn, displayLine })

  try {
    for (;;) {
      const item = await nextLine()
      if (item?.eof) { state.ended = true; break }
      if (item?.generation !== state.generation && !state.rl) continue
      const text = safeInput(item.line).trim()
      if (interactive && !state.busy) {
        // Wipe status line + typed input (+ dropdown); keep only the message itself in the chat history.
        if (item.synthetic) clearPromptArea()
        else if (state.statusRows) {
          output.write(chatBoxRedrawSequence(item.raw ?? item.line, termWidth(), state.statusRows))
          state.statusRows = 0
          const shown = safeInput(item.raw ?? item.line).trim()
          if (shown) out(`${formatUserMessage(shown, boxWidth())}\n`)
        }
      }
      state.pastes.clear()
      if (!text) { if (!state.busy) prompt(); continue }
      const command = text.split(/\s+/, 1)[0].toLowerCase()
      const isSlashCommand = /^\/[a-z][\w-]*$/.test(command) // "/home/me/app" is a path, not a command
      if (command === '/exit' || command === '/quit') { await localCommand('/exit'); continue }
      if (command === '/stop' && state.busy) { await localCommand('/stop'); continue }
      if (state.pendingApproval) {
        if (/^(?:y|yes)$/i.test(text)) {
          const pending = state.pendingApproval
          settleApproval(true)
          if (pending.server) core.rememberMcpApproval(agent.getSessionId(), pending.server)
        } else if (/^(?:a|always)$/i.test(text) && state.pendingApproval.canAlways) {
          const pending = state.pendingApproval
          state.sessionAllow.add(pending.name)
          settleApproval(true)
          if (pending.server) core.rememberMcpApproval(agent.getSessionId(), pending.server)
        } else if (/^(?:n|no)$/i.test(text)) settleApproval(false)
        else displayLine(state.pendingApproval.canAlways ? 'Reply y, a (always this session) or n to approve; /stop interrupts turn.' : 'Reply y or n to approve; /stop interrupts turn.')
        continue
      }
      if (state.busy) { displayLine('Agent busy; use /stop or wait for the current turn.'); continue }
      if (text.startsWith('/') && isSlashCommand) {
        try {
          if (await localCommand(text)) continue
          const shared = await sharedCommand?.({ channel: 'terminal', agent }, text)
          if (shared?.handled) { printResponse(shared.response); continue }
          printResponse(`Unknown command: ${text.split(/\s+/, 1)[0]}. Use /help.`)
        } catch (error) { displayLine(color(`Command error: ${error instanceof Error ? error.message : String(error)}`, ANSI.red)) }
        continue
      }
      await runTurn(text)
    }
  } finally {
    state.closing = true
    if (state.pendingApproval) settleApproval(false)
    if (state.busy) agent.interrupt()
    await state.activeTurn
    if (interactive && (state.turns > 0 || state.toolCalls > 0)) {
      let stats = {}
      try { stats = agent.getContextStats?.() || {} } catch {}
      let sessionId = ''
      try { sessionId = agent.getSessionId?.() || '' } catch {}
      out(`\n${formatSessionSummary({ model: agent.provider?.model || '', sessionId, startedAt: state.sessionStartedAt, turns: state.turns, toolCalls: state.toolCalls, toolErrors: state.toolErrors, percent: Number(stats.percent) || 0, width: boxWidth() })}\n`)
    }
    if (interactive) output.write('\x1b[23;0t')
    // Real cleanup: closes MCP transports and child processes. The old shutdownMcp?.() call
    // never existed on AIAgent, so MCP servers were left running after the CLI exited.
    try { await agent.shutdown?.() } catch {}
    if (state.sugTimer) clearImmediate(state.sugTimer)
    if (interactive) {
      input.off('data', onInputData)
      input.pause()
      resetPasteMode()
      process.off('exit', resetPasteMode)
    }
  }
  return { agent, state }
}

function parseArgs(argv) {
  const args = new Set(argv)
  if (args.has('--help') || args.has('-h')) return 'help'
  if (args.has('--version') || args.has('-v') || args.has('-versi')) return 'version'
  return 'run'
}

export function createCliAgent(core, options = {}) {
  const backgroundReview = options.backgroundReview ?? options.config?.gateway?.background_review ?? true
  return new core.AIAgent({ ...options, backgroundReview })
}

export async function main(argv = process.argv.slice(2)) {
  const mode = parseArgs(argv)
  if (mode === 'help') { console.log(HELP); return 0 }
  const { version } = JSON.parse(readFileSync(join(ROOT, 'vallencli/package.json'), 'utf8'))
  if (mode === 'version') { console.log(`vallenemperor v${version}`); return 0 }
  if (!existsSync(CORE_PATH)) {
    console.error('VallenAgent core build missing. Run: npm -w vallenagent run build')
    return 1
  }
  try {
    const core = await import(pathToFileURL(CORE_PATH).href)
    const config = core.loadConfig()
    const result = await runCli({ core, createAgent: options => createCliAgent(core, { ...options, config }) })
    return 0
  } catch (error) {
    console.error(`VallenCLI failed: ${error instanceof Error ? error.message : String(error)}`)
    return 1
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  process.exitCode = await main()
}
